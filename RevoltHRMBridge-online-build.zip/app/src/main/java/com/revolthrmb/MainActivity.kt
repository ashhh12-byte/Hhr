package com.revolthrmb

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private val serviceUuid = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
    private val measurementUuid = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
    private val watchServiceUuid = UUID.fromString("00000af0-0000-1000-8000-00805f9b34fb")
    private val watchNotifyUuids = listOf(
        UUID.fromString("00000af7-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("00000af2-0000-1000-8000-00805f9b34fb")
    )

    private lateinit var status: TextView
    private lateinit var bpmText: TextView
    private lateinit var logText: TextView
    private var scanner: BluetoothLeScanner? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var gatt: BluetoothGatt? = null
    private var server: BluetoothGattServer? = null
    private var measurement: BluetoothGattCharacteristic? = null
    private var currentBpm: Int? = null
    private val cccdUuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.TOP
        }
        val title = TextView(this).apply { text = "Revolt HRM Bridge"; textSize = 26f }
        status = TextView(this).apply { text = "Ready — grant Bluetooth permissions to begin."; textSize = 16f }
        bpmText = TextView(this).apply { text = "Heart rate: -- BPM"; textSize = 30f; setPadding(0, 28, 0, 24) }
        val start = Button(this).apply { text = "Start bridge"; setOnClickListener { startBridge() } }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener { stopBridge() } }
        logText = TextView(this).apply { textSize = 12f; text = "Log:\n"; setPadding(0, 20, 0, 0) }
        layout.addView(title); layout.addView(status); layout.addView(bpmText)
        layout.addView(start); layout.addView(stop); layout.addView(logText)
        setContentView(ScrollView(this).apply { addView(layout) })
        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 7)
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 7)
        }
    }

    private fun startBridge() {
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { status.text = "Turn Bluetooth on first."; return }
        if (Build.VERSION.SDK_INT >= 31 &&
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED)) {
            requestNeededPermissions(); status.text = "Grant the requested Bluetooth permissions, then tap Start."; return
        }
        scanner = adapter.bluetoothLeScanner
        advertiser = adapter.bluetoothLeAdvertiser
        if (scanner == null || advertiser == null) { status.text = "This phone does not expose BLE scanning/advertising."; return }
        startHrServer()
        startWatchScan()
        status.text = "Scanning for Revoltt X; advertising standard Heart Rate Monitor."
        log("Bridge started. Waiting for watch notifications.")
    }

    private fun startWatchScan() {
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(watchServiceUuid)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner?.startScan(listOf(filter), settings, scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            log("Found BLE device: ${device.name ?: "unnamed"}")
            scanner?.stopScan(this)
            gatt?.close()
            gatt = device.connectGatt(this@MainActivity, false, watchGattCallback, BluetoothDevice.TRANSPORT_LE)
        }
        override fun onScanFailed(errorCode: Int) { status.text = "BLE scan failed: $errorCode"; log("Scan failed: $errorCode") }
    }

    private val watchGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    log("Connected to watch; discovering services.")
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    log("Watch disconnected.")
                }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return
            val service = g.getService(watchServiceUuid)
            if (service == null) { log("Service 0x0AF0 not found."); return }
            watchNotifyUuids.forEach { uuid ->
                val ch = service.getCharacteristic(uuid)
                if (ch != null) {
                    g.setCharacteristicNotification(ch, true)
                    val descriptor = ch.getDescriptor(cccdUuid)
                    if (descriptor != null) {
                        if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        else { @Suppress("DEPRECATION") descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; @Suppress("DEPRECATION") g.writeDescriptor(descriptor) }
                    }
                    log("Subscribed to ${uuid.toString().take(8)}")
                }
            }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleWatchPacket(characteristic.uuid, value)
        }
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            handleWatchPacket(characteristic.uuid, characteristic.value ?: byteArrayOf())
        }
    }

    private fun handleWatchPacket(uuid: UUID, bytes: ByteArray) {
        val hex = bytes.joinToString(" ") { "%02X".format(it) }
        runOnUiThread { log("RX ${uuid.toString().take(8)}: $hex") }
        // Protocol is proprietary and not yet decoded. Do not guess a BPM from raw bytes.
        // Once the correct byte/format is confirmed, call publishBpm(decodedValue).
    }

    private fun startHrServer() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        server?.close()
        server = manager.openGattServer(this, object : BluetoothGattServerCallback() {
            override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
                runOnUiThread { log("HRM client ${if (newState == BluetoothProfile.STATE_CONNECTED) "connected" else "disconnected"}") }
            }
            override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
                descriptor.value = value
                if (responseNeeded) server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, value)
            }
        })
        val svc = BluetoothGattService(serviceUuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        measurement = BluetoothGattCharacteristic(
            measurementUuid,
            BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_READ
        )
        measurement?.addDescriptor(BluetoothGattDescriptor(cccdUuid, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        svc.addCharacteristic(measurement)
        server?.addService(svc)
        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM).setConnectable(true).build()
        val data = AdvertiseData.Builder().setIncludeDeviceName(false).addServiceUuid(ParcelUuid(serviceUuid)).build()
        advertiser?.startAdvertising(settings, data, advertiseCallback)
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) { runOnUiThread { log("Advertising Heart Rate Service (0x180D).") } }
        override fun onStartFailure(errorCode: Int) { runOnUiThread { log("Advertising failed: $errorCode") } }
    }

    private fun publishBpm(bpm: Int) {
        if (bpm !in 30..240) return
        currentBpm = bpm
        val payload = byteArrayOf(0x00, bpm.toByte())
        runOnUiThread { bpmText.text = "Heart rate: $bpm BPM" }
        measurement?.value = payload
        server?.notifyCharacteristicChanged(null, measurement, false)
    }

    private fun stopBridge() {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { advertiser?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        gatt = null; server = null
        status.text = "Stopped."
        log("Bridge stopped.")
    }

    private fun log(message: String) {
        logText.append("$message\n")
    }

    override fun onDestroy() { stopBridge(); super.onDestroy() }
}
