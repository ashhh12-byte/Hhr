# Revolt HRM Bridge (prototype 0.1)

Android Studio starter project for the one-phone experiment:
Fastrack Revoltt X -> Android BLE client -> standard BLE Heart Rate Service (0x180D) -> Strava-compatible HRM client.

## Current status
- Scans for the watch's observed service 0x0AF0.
- Attempts to subscribe to observed notification characteristics 0x0AF7 and 0x0AF2.
- Logs incoming bytes in hexadecimal.
- Exposes a standard Heart Rate Service (0x180D) with Heart Rate Measurement (0x2A37).

## Important limitation
The watch's proprietary notification payload has not yet been decoded. The app deliberately does NOT guess BPM from arbitrary bytes, so it currently advertises the standard HRM service but will not publish a real heart rate until the packet format is confirmed and `publishBpm(decodedValue)` is called with the decoded value.

Same-phone scanning/advertising and Strava compatibility depend on Android device/OS Bluetooth behavior and must be tested. This is source code, not an installed APK.

## Build
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build APK(s), then install the debug APK on the Android phone.
5. Grant Bluetooth permissions, keep Bluetooth on, and tap Start bridge.
6. Check the on-screen log for notifications from 0x0AF7 / 0x0AF2.

## Next protocol step
Capture several notification packets while the watch is showing different known heart rates. Compare the bytes against those displayed BPM values to identify the packet field/encoding. Do not assume a byte offset without evidence.
